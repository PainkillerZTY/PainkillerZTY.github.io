#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

uniform sampler2D texturePlane;

void main()
{
    FragColor = texture(texturePlane, TexCoord);
}
